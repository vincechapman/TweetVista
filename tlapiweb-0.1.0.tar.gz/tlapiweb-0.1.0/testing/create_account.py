import pprint
import time
import unittest
from requests.exceptions import ConnectionError
import settings
from TLApi.TLApiWeb.connect import WebConnection

class TestWebAccess(unittest.TestCase):
    def setUp(self):
        self.wc = WebConnection(url=settings.CONNECT_URL)
    def test_010_createaccount(self):
        try:
            data = self.wc.create_client_account(
                username=settings.USER_NAME,
                firstname=settings.USER_FIRSTNAME,
                lastname=settings.USER_SURNAME,
                email=settings.USER_EMAIL,
                password=settings.USER_PASSWORD
            )
            pass
        except Exception as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        self.assertEqual(data.get('status',400), 200,data.get('msg','Failed unknown'))
    def test_011_create_bare_account(self):
        try:
            data = self.wc.create_client_account(
                username=settings.BARE_USER_NAME,
                firstname=settings.USER_FIRSTNAME,
                lastname=settings.USER_SURNAME,
                email=settings.USER_EMAIL,
                password=settings.BARE_USER_PASSWORD,
                company_name=settings.BARE_USER_COMPANY,
                company_role=settings.BARE_USER_CO_ROLE,
                contact_number=settings.BARE_USER_CONTACT,
                number_of_users=settings.BARE_USER_NO_USERS,
            )
            pass
        except Exception as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        self.assertEqual(data.get('status',400), 200,data.get('msg','Failed unknown'))

    def test_011a_create_bare_account_min(self):
        try:
            data = self.wc.create_client_account(
                username=settings.BARE_USER_EMAIL,
                firstname=settings.USER_FIRSTNAME,
                lastname=settings.USER_SURNAME,
                email=settings.BARE_USER_EMAIL,
                password=settings.BARE_USER_PASSWORD,
            )
            pprint.pprint(data, indent=4)
        except Exception as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        self.assertEqual(data.get('status',400), 200,data.get('msg','Failed unknown'))
    def test_012_twitter_account_set(self):
        data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        data = self.wc.is_twitter_account_set()
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'twitter account not auth'))
    def test_014_twitter_account_not_set(self):
        data = self.wc.log_user_in(username=settings.BARE_USER_NAME, password=settings.BARE_USER_PASSWORD)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        data = self.wc.is_twitter_account_set()
        self.assertEqual(data.get('status', 200), 400, data.get('msg', 'twitter account authorised'))
    def test_016_get_current_user(self):
        data = self.wc.log_user_in(username=settings.BARE_USER_NAME, password=settings.BARE_USER_PASSWORD)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        data = self.wc.get_current_user()
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get current user'))
        pprint.pprint(data, indent=4)

    def test_018_no_current_user(self):
        data = self.wc.log_user_in(username=settings.USER_NAME+'x', password=settings.USER_PASSWORD+'x')
        self.assertEqual(data.get('status', 200), 400, data.get('msg', 'logged in'))
        data = self.wc.get_current_user()
        self.assertEqual(data.get('status', 404), 200, data.get('msg', 'current user'))
        pprint.pprint(data, indent=4)
    def test_020_is_logged_out(self):
        try:
            data = self.wc.is_loggedin()
            self.assertEqual(data.get('status', 500), 404, data.get('msg','Already logged in'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')

    def test_030_log_in(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME,password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')

    def test_040_is_logged_in(self):
        try:
            data = self.wc.is_loggedin()
            self.assertEqual(data.get('status', 500), 200, data.get('msg','Not logged in'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')

    def test_050_log_out(self):
        try:
            data = self.wc.logout()
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
    def test_060_delete_campaigns(self):
        data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        data = self.wc.get_client_campaigns()
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot get campaigns'))
        for campaign in data.get('data',[]):
            data = self.wc.delete_campaign(campaign_name=campaign.get('name',''))
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot delete campaigns'))
    def test_065_nocampaigns(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME,password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_client_campaigns()
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot get campaigns'))
            self.assertTrue(isinstance(data.get('data',{}),list) , 'data must be list')
            self.assertEqual(len(data.get('data',[])),0,'there should be no campaigns')
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_070_create_brand_campaign(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.create_client_campaign(
                settings.CAMP_BRND_NAME,
                start_date=settings.START_DATE,
                end_date=None,
                campaign_type=settings.CAMP_BRND_TYPE
            )
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot get campaign'))
            campaign_id = data.get('data',{}).get('campaign_id',0)
            for keyword in settings.CAMP_BRND_POS_KEYWORDS:
                data = self.wc.store_campaign_keyword(campaign_id, keyword, keyword_order='fixed')
                self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot store pos keyword'))
            for keyword in settings.CAMP_BRND_NEG_KEYWORDS:
                data = self.wc.store_campaign_keyword(campaign_id, keyword, keyword_type='negative')
                self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot store neg keyword'))
            data = self.wc.start_campaign_feed(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot start campaign feed'))
            time.sleep(120)
            data = self.wc.stop_campaign_feed(campaign_id=campaign_id)
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')


    def test_080_get_brand_campaign_by_name(self):
        try:
            data=self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data=self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_BRND_NAME)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            pprint.pprint(data, indent=4)
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')
    def test_084_start_campaign_feed(self):
        try:
            data=self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data=self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_BRND_NAME)
            campaign_id = data.get('data',{}).get('id',0)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            data = self.wc.start_campaign_feed(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot start campaign feed'))

        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_086_stop_campaign_feed(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_BRND_NAME)
            campaign_id = data.get('data', {}).get('id', 0)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            data = self.wc.stop_campaign_feed(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot stop campaign feed'))

        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')
    def test_090_delete_brand_keyword(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_BRND_NAME)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            campaign_id = data.get('data',{}).get('id',0)
            data = self.wc.get_campaign_keywords(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get keywords'))
            cnt = 0
            for keyword in data.get('data',[]):
                if keyword.get('text','') == settings.CAMP_BRND_POS_KEYWORDS[0] \
                        and keyword.get('type', '') == 'positive' \
                        and keyword.get('order', '') == 'fixed':
                    data = self.wc.delete_campaign_keyword(campaign_id=campaign_id,keyword_id=keyword.get('id',0))
                    self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable delete keywords'))
                    cnt += 1
                    break
            self.assertEqual(cnt, 1, 'No Keywords deleted')
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')
    def test_085_delete_brand_campaign(self):
        data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        data = self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_BRND_NAME)
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
        campaign = data.get('data',{})
        data = self.wc.delete_campaign(campaign_name=campaign.get('name', ''))
        self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot delete campaigns'))


    def test_100_brand_keywords(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_BRND_NAME)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            pprint.pprint(data, indent=4)
            campaign_id = data.get('data',{}).get('id',0)
            o_kylist = ['this is a phrase','phrase is this a','socks']
            data = self.wc.store_campaign_keyword(campaign_id, o_kylist[0], 'fixed')
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to create keyword'))
            data = self.wc.store_campaign_keyword(campaign_id, o_kylist[1], 'any')
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to create keyword'))
            data = self.wc.store_campaign_keyword(campaign_id, o_kylist[2], 'none')
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to create keyword'))
            data = self.wc.get_campaign_keywords(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get keywords'))
            keywords=data.get('data',[])
            self.assertEqual(len(keywords), 3, data.get('msg', 'unable to get all keywords'))
            kylist = []
            for keyword in keywords:
                if keyword.get('text','') not in o_kylist:
                    self.fail(f"Keyword {keyword.get('text','')} not in {o_kylist}")

        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_110_create_affiliate_campaign(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.create_client_campaign(
                settings.CAMP_AFF_NAME,
                start_date=settings.START_DATE,
                end_date=None,
                campaign_type=settings.CAMP_AFF_TYPE,
                affiliate_name=settings.CAMP_AFF_NAME,
                affiliate_url=settings.CAMP_AFF_URL,
                affiliate_short=settings.CAMP_AFF_SHORT
            )
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot get campaign'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_120_get_aff_campaign_by_name(self):
        try:
            data=self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data=self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_AFF_NAME)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            pprint.pprint(data, indent=4)
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_130_delete_aff_keywords(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_AFF_NAME)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get affiliate campaign'))
            pprint.pprint(data, indent=4)
            campaign_id = data.get('data',{}).get('id',0)
            data = self.wc.delete_all_campaign_keywords(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable delete keywords'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_140_aff_keywords(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_client_campaign_by_name(campaign_name=settings.CAMP_AFF_NAME)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get brand campaign'))
            pprint.pprint(data, indent=4)
            campaign_id = data.get('data',{}).get('id',0)
            o_kylist = ['this is a phrase','phrase is this a','socks']
            data = self.wc.store_campaign_keyword(campaign_id, o_kylist[0], 'fixed')
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to create keyword'))
            data = self.wc.store_campaign_keyword(campaign_id, o_kylist[1], 'any')
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to create keyword'))
            data = self.wc.store_campaign_keyword(campaign_id, o_kylist[2], 'none')
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to create keyword'))
            data = self.wc.get_campaign_keywords(campaign_id=campaign_id)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to get keywords'))
            keywords=data.get('data',[])
            self.assertEqual(len(keywords), 3, data.get('msg', 'unable to get all keywords'))
            kylist = []
            for keyword in keywords:
                if keyword.get('text','') not in o_kylist:
                    self.fail(f"Keyword {keyword.get('text','')} not in {o_kylist}")

        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

    def test_150_delete_affiliate_campaign(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')
    def test_155_create_trending_campaign(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.get_country_codes()
            self.assertEqual(data.get('status', 500), 200, data.get('msg', 'unable to get woeid codes'))
            woeid = -1
            for code in data.get('data',[]):
                if code.get('name', '') == 'United Kingdom':
                    woeid=code.get('woeid', 0)
                    break
            self.assertNotEqual(woeid, -1, 'unable to get uk code')
            data = self.wc.create_client_campaign(
                settings.CAMP_TREND_NAME,
                start_date=settings.START_DATE,
                end_date=None,
                campaign_type=settings.CAMP_TREND_TYPE,
                woeid=woeid
            )
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'cannot create campaign'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')
'''            
    def test_11_user_twitter_auth(self):
        try:
            data = self.wc.log_user_in(username=settings.USER_NAME, password=settings.USER_PASSWORD)
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'unable to login'))
            data = self.wc.is_twitter_account_set()
            self.assertEqual(data.get('status', 400), 200, data.get('msg', 'twitter account not set'))
        except ConnectionError as msg:
            self.fail(f'cannot connect to {settings.CONNECT_URL}')
        except Exception as msg:
            self.fail(f'{msg}')

'''


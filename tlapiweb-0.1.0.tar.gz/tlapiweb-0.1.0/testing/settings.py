CONNECT_URL_local='http://127.0.0.1:8002/'
CONNECT_URL_lan='http://192.168.1.10:90/'
CONNECT_URL_remote='https://tlapi.ictbenchmark.org/'
USER_NAME='test_user'
USER_FIRSTNAME='testfirst'
USER_SURNAME='testsur'
USER_PASSWORD='test_password'
USER_EMAIL='test_user@osrg.org'
BARE_USER_NAME='bare_account'
BARE_USER_PASSWORD='bare_pass_word'
CAMP_AFF_NAME='affiliate test'
CAMP_AFF_URL='http://osrg.org'
CAMP_AFF_SHORT='short_code'
CAMP_AFF_TYPE='affiliate'
CAMP_TREND_NAME='trending test'
CAMP_BRND_NAME='brand protection test'
CAMP_BRND_TYPE='brand-protection'
CAMP_BRND_POS_KEYWORDS=['putin','ukraine','russia','crimea']
CAMP_BRND_NEG_KEYWORDS=['shirts','socks']
CAMP_TREND_TYPE='trending'
START_DATE='01-01-2022'
TEST_CAMPAIGN = 'Affiliate Campaign'
DELETE_CAMPAIGN = 'affiliate test'
#PROD_CAMPAIGN = 'Unit Test Campaign'
PROD_CAMPAIGN = 'helix'
SERVER_TARGET='local'
if SERVER_TARGET == 'live':
    CONNECT_URL = CONNECT_URL_remote
    DELETE_CAMPAIGN = 'Test Affiliate Campaign'
    TEST_CAMPAIGN = 'Unit Test Campaign'
elif SERVER_TARGET == 'local':
    CONNECT_URL = CONNECT_URL_local
    TEST_CAMPAIGN = 'brand protection test'
    DELETE_CAMPAIGN = 'affiliate test'
elif SERVER_TARGET == 'lan':
    CONNECT_URL = CONNECT_URL_lan
    DELETE_CAMPAIGN = 'Test Affiliate Campaign'
    TEST_CAMPAIGN = 'ukraine'


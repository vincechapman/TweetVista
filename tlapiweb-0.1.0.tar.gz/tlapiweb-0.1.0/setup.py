from setuptools import setup

setup(
    name='tlapiweb',
    version='0.1.0',
    description='Connection to Tweetlocator api',
    url='https://osrg.org/',
    author='David Hagan',
    author_email='d.hagan@osrg.org',
    license='Proprietary',
    packages=['TLApiWeb'],
    install_requires=['requests',
                      ],

    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: None',
        'License :: Other/Proprietary License',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3.10',
    ],
)

import json
import logging
import pprint
import requests
import random

__author__ = 'dhagan'
log = logging.getLogger('TLApi_Singleton')
log.setLevel(logging.INFO)
logging.basicConfig(level=logging.INFO)


class InvalidHttpResponse(Exception):
    status_code = -1
    value = ''

    def __init__(self, value, status_code):
        self.status_code = status_code
        super().__init__(value)
        self.value = value

    def __str__(self):
        return repr(self.value)

    def get_status(self):
        return self.status_code


class InvalidLogin(Exception):
    def __init__(self, value):
        super(InvalidLogin, self).__init__(value)
        self.value = value

    def __str__(self):
        return repr(self.value)


class NotLoggedIn(Exception):
    def __init__(self, value, status_code):
        super(NotLoggedIn, self).__init__(value)
        self.value = value
        self.status_code = status_code

    def __str__(self):
        return repr(self.value)

    def get_status(self):
        return self.status_code


def display_dict(dict_data):
    pprint.pprint(dict_data, indent=4)


class WebConnection:
    __logged_in = False
    streams = {}
    instance = None
    _userid = None
    _password = None
    _url = None
    _sessionid = None
    _session = None

    def __new__(cls, **kwargs):
        if cls.instance is None:
            log.info(f'Starting WebConnection Singleton')
            cls.instance = super().__new__(cls)

        if cls.instance._userid is None:
            cls.instance._userid = kwargs.get('userid', None)

        if cls.instance._password is None:
            cls.instance._password = kwargs.get('password', None)

        if cls.instance._url is None:
            cls.instance._url = kwargs.get('url', None)

        if cls.instance._sessionid is None:
            cls.instance._sessionid = kwargs.get('sessionid', None)
        if cls.instance._session is None:
            cls.instance._session = requests.session()
        return cls.instance

    @property
    def userid(self):
        return self._userid

    @userid.setter
    def userid(self, value):
        self._userid = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value

    @property
    def url(self):
        return self._url

    @url.setter
    def url(self, value):
        self._url = value

    @property
    def sessionid(self):
        return self._sessionid

    @sessionid.setter
    def sessionid(self, value):
        self._sessionid = value

    @property
    def session(self):
        return self._session

    @session.setter
    def session(self, value):
        self._session = value

    def set_headers(self):
        self._session.headers.update({'TLApi-Auth': 'True'})
        self._session.headers.update({'TLApi-User': self._userid})
        self._session.headers.update({'TLApi-Pass': self._password})

    def unset_headers(self):
        self._session.headers.update({'TLApi-Auth': None})
        self._session.headers.update({'TLApi-User': None})
        self._session.headers.update({'TLApi-Pass': None})

    def authenticate_user(self):
        ret_val = False
        sessionid = self.get_sessionid()
        if sessionid is not None:
            requests.utils.add_dict_to_cookiejar(self._session.cookies, {'sessionid': sessionid})
        else:
            self.set_headers()
        try:
            r = self._session.post(self.url + 'common/auth_user/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}
        ret_val = json.loads(r.text)
        return ret_val

    def is_authenticated(self):
        ret_val = False
        sessionid = self.get_sessionid()
        if sessionid is not None:
            requests.utils.add_dict_to_cookiejar(self._session.cookies, {'sessionid': sessionid})
        else:
            self.set_headers()
        try:
            r = self._session.post(self.url + 'common/is_auth_user/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}
        ret_val = json.loads(r.text)
        return ret_val

    def logout(self):
        try:
            r = self._session.post(self.url + 'common/user_logout/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}

        try:
            data = json.loads(r.text)
            if data.get('status',400) == 200:
                self.unset_headers()
        except Exception as msg:
            data = {"success": False, "error": f'{msg}'}

        return data

    def log_user_in(self, username=None, password=None):
        if not (username is None and password is None):
            self.userid = username
            self.password = password
            self.set_headers()
        try:
            r = self._session.post(self.url + 'common/user_login/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}

        return self.format_data(r)

    def is_loggedin(self):
        ret_val = False
        try:
            r = self._session.post(self.url + 'common/is_user_loggedin/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}

        return self.format_data(r)
    def get_current_user(self):
        try:
            r = self._session.post(self.url + 'client/get_current_user/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}

        return self.format_data(r)
    def get_client_campaigns(self):
        try:
            r = self._session.post(self.url + 'client/get_campaigns/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}

        return self.format_data(r)
    def get_client_campaigns_slow(self):
        try:
            r = self._session.post(self.url + 'client/get_campaigns_slow/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} : {msg} ",'status':404}

        return self.format_data(r)

    def get_client_campaign_by_id(self, campaign_id):
        values = {'campaign_id': campaign_id}
        try:
            r = self._session.post(self.url + 'client/get_campaign/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        return self.format_data(r)

    def get_client_campaign_by_name(self, campaign_name):
        values = {'campaign_name': campaign_name}
        try:
            r = self._session.post(self.url + 'client/get_campaign/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        return self.format_data(r)

    def create_campaign_from_json(self, campaign):
        campaign_json = json.dumps(campaign)
        values = {'campaign_json': campaign_json}
        try:
            r = self._session.post(self.url + 'client/create_json_campaign/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        return self.format_data(r)


    def get_country_codes(self):
        try:
            r = self._session.post(self.url + 'common/country_codes/')
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}
        return self.format_data(r)

    def create_client_campaign(self, campaign_name,
                               start_date=None,
                               end_date=None,
                               campaign_type='brand-protection',
                               affiliate_name=None,
                               affiliate_url=None,
                               affiliate_short=None,
                               woeid=None,
                               ):
        '''
        :param campaign_name:
        :param start_date: None = start at todays date or 'dd-mm-yyy'
        :param end_date
        :param campaign_type: 'brand-protection','trending' or 'profile' or 'affiliate'
        :param affiliate_name
        :param affiliate_url
        :param affiliate_short
        :param woeid
        :return:
        '''
        values = {'campaign_name': campaign_name,
                  'start_date': start_date,
                  'end_date': end_date,
                  'campaign_type': campaign_type,
                  'affiliate_name': affiliate_name,
                  'affiliate_url': affiliate_url,
                  'affiliate_short': affiliate_short,
                  'woeid': woeid
                  }
        try:
            r = self._session.post(self.url + 'client/create_campaign/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}
        return self.format_data(r)
    def update_client_campaign(self,
                               campaign_id,
                               campaign_name=None,
                               start_date=None,
                               end_date=None,
                               affiliate_name=None,
                               affiliate_url=None,
                               affiliate_short=None,
                               woeid=None,
                               ):
        '''
        :param campaign_id:
        :param campaign_name:
        :param start_date:
        :param end_date
        :param affiliate_name
        :param affiliate_url
        :param affiliate_short
        :param woeid
        :return:
        '''
        values = {'campaign_id': campaign_id,
                  'campaign_name': campaign_name,
                  'start_date': start_date,
                  'end_date': end_date,
                  'affiliate_name': affiliate_name,
                  'affiliate_url': affiliate_url,
                  'affiliate_short': affiliate_short,
                  'woeid': woeid
                  }
        try:
            r = self._session.post(self.url + 'client/update_campaign/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}
        return self.format_data(r)
    def get_twitter_stream(self, campaign_id):
        self.streams[campaign_id] = False
        values = {'campaign_id': campaign_id}
        with self._session.post(self.url + 'client/tweet_stream/', values, headers=None, stream=True) as resp:
            for line in resp.iter_lines(chunk_size=250, decode_unicode=True):
                close_stream = self.streams.get(campaign_id, True)
                if close_stream:
                    resp.close()
                    break
                if line:
                    yield line

    def get_page_tweets_old(self, campaign_id, page_len=10, tweet_id=None):
        values = {'campaign_id': campaign_id, 'page_len': page_len, 'tweet_id': tweet_id}
        try:
            r = self._session.post(self.url + 'client/latest_tweets_old/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def get_page_tweets(self,
                        campaign_id,
                        page_len=0,
                        tweet_id=None,
                        start_score=0,
                        key_words=None,
                        commercial_tweets=False,
                        non_commercial_tweets=False):
        values = {'campaign_id': campaign_id,
                  'page_len': page_len,
                  'tweet_id': tweet_id,
                  'start_score': start_score,
                  'key_words': key_words,
                  'commercial_tweets': commercial_tweets,
                  'non_commercial_tweets': non_commercial_tweets}
        try:
            r = self._session.post(self.url + 'client/latest_tweets/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta
    def count_campaign_tweets(self, campaign_id,
                              start_date=None,
                              end_date=None,
                              start_score=0,
                              end_score=0,
                              key_words=None,
                              tweet_cutoff=0,
                              commercial_tweets=False,
                              non_commercial_tweets=False):
        values = {'campaign_id': campaign_id,
                  'start_date': start_date,
                  'end_date': end_date,
                  'start_score': start_score,
                  'end_score': end_score,
                  'key_words': key_words,
                  'tweet_cutoff': tweet_cutoff,
                  'commercial_tweets': commercial_tweets,
                  'non_commercial_tweets': non_commercial_tweets
                  }
        try:
            r = self._session.post(self.url + 'client/count_campaign_tweets/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        return self.format_data(r)

    def get_page_of_tweets(self, campaign_id,
                           page_no=1,
                           page_len=20,
                           start_date=None,
                           end_date=None,
                           start_score=0,
                           end_score=0,
                           key_words=None,
                           tweet_cutoff=0,
                           tweet_sort='asc',
                           commercial_tweets=False,
                           non_commercial_tweets=False):
        values = {'campaign_id': campaign_id,
                  'page_no': page_no,
                  'page_len': page_len,
                  'start_date': start_date,
                  'end_date': end_date,
                  'start_score': start_score,
                  'end_score': end_score,
                  'key_words': key_words,
                  'tweet_cutoff': tweet_cutoff,
                  'tweet_sort': tweet_sort,
                  'commercial_tweets': commercial_tweets,
                  'non_commercial_tweets': non_commercial_tweets
                  }
        try:
            r = self._session.post(self.url + 'client/get_page_of_tweets/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        return self.format_data(r)

    def test_annotation(self, campaign_id,
                        page_no=1,
                        page_len=20,
                        start_date=None,
                        end_date=None,
                        start_score=0,
                        end_score=0,
                        key_words=None,
                        tweet_cutoff=0,
                        tweet_sort='asc'):
        values = {'campaign_id': campaign_id,
                  'page_no': page_no,
                  'page_len': page_len,
                  'start_date': start_date,
                  'end_date': end_date,
                  'start_score': start_score,
                  'end_score': end_score,
                  'key_words': key_words,
                  'tweet_cutoff': tweet_cutoff,
                  'tweet_sort': tweet_sort
                  }
        try:
            r = self._session.post(self.url + 'client/test_annotation/', values)
        except Exception as msg:
            return {'data': None, 'msg': f"Connection Failed to {self.url} : {msg} ", 'status': 404}

        return self.format_data(r)

    def get_tweets_for_campaign(self, campaign_id,
                                page_len=0,
                                next_id=0,
                                start_date=None,
                                end_date=None,
                                start_score=0,
                                end_score=0,
                                key_words=None,
                                tweet_cutoff=0,
                                page_direction='forward',
                                commercial_tweets=False,
                                non_commercial_tweets=False):
        values = {'campaign_id': campaign_id,
                  'page_len': page_len,
                  'next_id': next_id,
                  'start_date': start_date,
                  'end_date': end_date,
                  'start_score': start_score,
                  'end_score': end_score,
                  'key_words': key_words,
                  'tweet_cutoff': tweet_cutoff,
                  'page_direction': page_direction,
                  'commercial_tweets': commercial_tweets,
                  'non_commercial_tweets': non_commercial_tweets}

        r = self._session.post(self.url + 'client/campaign_tweets/', values)
        return self.format_data(r)

    def format_data(self, response):
        try:
            dta = json.loads(response.text)
            if isinstance(dta, dict):
                dta['status'] = response.status_code
        except Exception as msg:
            dta = {'status': response.status_code, 'msg': {msg}}
            log.error(f'{msg} {response.text}')
        return dta

    def save_to_locker(self, campaign_id, tweet_id):
        values = {'campaign_id': campaign_id, 'tweet_id': tweet_id}
        r = self._session.post(self.url + 'client/save_to_locker/', values)
        return self.format_data(r)

    def save_to_excluded_tweets(self, campaign_id, tweet_id):
        values = {'campaign_id': campaign_id, 'tweet_id': tweet_id}
        r = self._session.post(self.url + 'client/save_to_excluded_tweets/', values)
        return self.format_data(r)

    def delete_from_locker(self, campaign_id, tweet_id):
        values = {'campaign_id': campaign_id, 'tweet_id': tweet_id}
        r = self._session.post(self.url + 'client/delete_from_locker/', values)
        return self.format_data(r)

    def delete_from_excluded_tweets(self, campaign_id, tweet_id):
        values = {'campaign_id': campaign_id, 'tweet_id': tweet_id}
        r = self._session.post(self.url + 'client/delete_from_excluded_tweets/', values)
        return self.format_data(r)

    def get_tweet_locker(self, campaign_id):
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/get_tweet_locker/', values)
        return self.format_data(r)

    def get_excluded_tweets(self, campaign_id):
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/get_excluded_tweets/', values)
        return self.format_data(r)

    def get_tweets_from_list(self, campaign_id,tweet_list):
        values = {'campaign_id': campaign_id, 'tweet_list': tweet_list}
        r = self._session.post(self.url + 'client/get_tweets_from_list/', values)
        return self.format_data(r)

    def clear_tweet_locker(self, campaign_id):
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/clear_locker/', values)
        return self.format_data(r)

    def clear_excluded_tweets(self, campaign_id):
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/clear_excluded_tweets/', values)
        return self.format_data(r)


    def get_campaign_keywords(self, campaign_id):
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/get_keywords/', values)
        return self.format_data(r)

    def save_to_campaign_filters(self, campaign_id, filter_name, filter_keywords):
        if filter_keywords is None:
            filter_keywords = list()
        values = {'campaign_id': campaign_id,'filter_name':filter_name,'filter_keywords': filter_keywords}
        r = self._session.post(self.url + 'client/save_to_campaign_filters/', values)
        return self.format_data(r)

    def delete_from_campaign_filters(self,campaign_id, filter_name,):
        values = {'campaign_id': campaign_id,'filter_name':filter_name}
        r = self._session.post(self.url + 'client/delete_from_campaign_filters/', values)
        return self.format_data(r)

    def get_campaign_filters(self,campaign_id):
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/get_campaign_filters/', values)
        return self.format_data(r)
    def store_campaign_keyword(self, campaign_id, keyword_text, keyword_order='none', keyword_type='positive'):
        '''
        :param campaign_id: key of campaign
        :param keyword_text: phrase or word
        :param keyword_order: 'none' = no order,'fixed' = string must exist in tweet, 'any' = all words in phrase exist in tweet in any order
        :param keyword_type: 'positive' or 'negative'
        :return: { 'status':xxx,'data': object,'msg':string }
        '''
        values = {'campaign_id': campaign_id,
                  'text': keyword_text,
                  'keyword_order': keyword_order,
                  'keyword_type': keyword_type}
        r = self._session.post(self.url + 'client/store_keyword/', values)
        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def delete_campaign(self, campaign_id=None, campaign_name=None):
        '''
        :param campaign_id:
        :param campaign_name:
        :return:
        '''
        values = {'campaign_id': campaign_id, 'campaign_name': campaign_name}
        r = self._session.post(self.url + 'client/delete_campaign/', values)
        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def delete_campaign_keyword(self, campaign_id, keyword_id):
        '''
        :param campaign_id:
        :param keyword_id:
        :return:
        '''
        values = {'campaign_id': campaign_id, 'keyword_id': keyword_id}
        r = self._session.post(self.url + 'client/delete_keyword/', values)
        return self.format_data(r)

    def delete_all_campaign_keywords(self, campaign_id):
        '''
        :param campaign_id:
        :return:
        '''
        values = {'campaign_id': campaign_id}
        r = self._session.post(self.url + 'client/delete_all_keywords/', values)
        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def start_campaign_feed(self, campaign_id=None, campaign_name=None):
        '''
        :param campaign_id:
        :param campaign_name:
        :return:
        '''
        values = {'campaign_id': campaign_id, 'campaign_name': campaign_name}
        r = self._session.post(self.url + 'client/start_campaign_feed/', values)
        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def stop_campaign_feed(self, campaign_id=None, campaign_name=None):
        '''
        :param campaign_id:
        :param campaign_name:
        :return:
        '''
        values = {'campaign_id': campaign_id, 'campaign_name': campaign_name}
        r = self._session.post(self.url + 'client/stop_campaign_feed/', values)
        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def get_keyword_literals(self):
        r = self._session.post(self.url + 'common/keyword_lits/')
        dta = json.loads(r.text)
        data = dta['data']
        status = r.status_code
        if status != 200:
            data = {}
        return data

    def get_handle_data(self, handle_id):
        values = {'handle_id': handle_id}
        r = self._session.post(self.url + 'client/handle_data/', values)
        dta = json.loads(r.text)
        if isinstance(dta, dict):
            dta['status'] = r.status_code
        return dta

    def get_twitter_app(self):
        r = self._session.post(self.url + 'common/twitter_app/')
        dta = json.loads(r.text)
        return dta

    def store_user_twitter_account(self, only_tokens):
        with open('token_file', 'w') as of:
            json.dump(only_tokens, of)
        only_tokens = json.dumps(only_tokens)
        values = {'oauth_tokens': only_tokens}
        r = self._session.post(self.url + 'common/store_twitter_tokens/', values)
        dta = json.loads(r.text)
        return dta

    def create_client_account(self,
                              username=None,
                              firstname=None,
                              lastname=None,
                              email=None,
                              password='changeme',
                              company_name='',
                              company_role='',
                              number_of_users=0,
                              contact_number=''
                              ):
        values = {
            'username': username,
            'firstname': firstname,
            'lastname': lastname,
            'email': email,
            'password': password,
            'company_name':company_name,
            'company_role':company_role,
            'number_of_users':number_of_users,
            'contact_number':contact_number,

        }
        try:
            r = self._session.post(self.url + 'client/create_account/', values)
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} endpoint {'client/create_account/'}: {msg} ",'status':404}
        # dta = json.loads(r.text)
        return self.format_data(r)

    def is_twitter_account_set(self):
        try:
            r = self._session.post(self.url + 'common/twitter_account_set/')
        except Exception as msg:
            return {'data':None,'msg':f"Connection Failed to {self.url} endpoint {'client/create_account/'}: {msg} ",'status':404}

        return self.format_data(r)

    def like_tweet(self, campaign_id, tweet_id):
        values = {
            'campaign_id': campaign_id,
            'tweet_id': tweet_id,
        }
        r = self._session.post(self.url + 'client/like_tweet/', values)
        dta = json.loads(r.text)
        return dta

    def unlike_tweet(self, campaign_id, tweet_id):
        values = {
            'campaign_id': campaign_id,
            'tweet_id': tweet_id,
        }
        r = self._session.post(self.url + 'client/unlike_tweet/', values)
        dta = json.loads(r.text)
        return dta

    def follow_twitter_account(self, campaign_id, handle):
        values = {
            'campaign_id': campaign_id,
            'handle': handle,
        }
        r = self._session.post(self.url + 'client/follow_twitter_account/', values)
        dta = json.loads(r.text)
        return dta

    def unfollow_twitter_account(self, campaign_id, handle):
        values = {
            'campaign_id': campaign_id,
            'handle': handle,
        }
        r = self._session.post(self.url + 'client/unfollow_twitter_account/', values)
        dta = json.loads(r.text)
        return dta

    def post_tweet(self, campaign_id, txt, image=None, name='', url=None, short=''):
        values = {
            'campaign_id': campaign_id,
            'text': txt,
            'image': image,
            'name': name,
            'url': url,
            'short': short
        }
        r = self._session.post(self.url + 'client/post_tweet/', values)
        dta = json.loads(r.text)
        return dta
    def reply_to_tweet(self, campaign_id, txt, tweet_id=None, handle=None,quote_tweet=False, image=None, name='', url=None, short=''):
        values = {
            'campaign_id': campaign_id,
            'text': txt,
            'tweet_id':tweet_id,
            'quote_tweet':quote_tweet,
            'handle' : handle,
            'image': image,
            'name': name,
            'url': url,
            'short': short
        }
        r = self._session.post(self.url + 'client/reply_to_tweet/', values)
        dta = json.loads(r.text)
        return dta
    def retweet(self, campaign_id, tweet_id=None):
        values = {
            'campaign_id': campaign_id,
            'tweet_id':tweet_id
        }
        r = self._session.post(self.url + 'client/retweet/', values)
        dta = json.loads(r.text)
        return dta

    def get_user_groups(self, user_id):
        values = {
            'user_id': user_id
        }
        r = self._session.post(self.url + 'common/user_groups/', values)
        dta = json.loads(r.text)
        return dta

    def close_stream(self, campaign_id):
        self.streams[campaign_id] = True

    def get_sessionid(self):
        sessionid = None
        if self._sessionid is None:
            s_cookie_jar = self.get_session_cookie()
            if s_cookie_jar is not None:
                self._sessionid = s_cookie_jar.get('sessionid', None)

        return self._sessionid

    def get_session_cookie(self):
        if self._session is not None:
            return self._session.cookies
        return None


class RandWords:
    instance = None
    words = None

    def __new__(cls, **kwargs):
        if cls.instance is None:
            log.info(f'Starting RandWords Singleton')
            cls.instance = super().__new__(cls)
        if cls.words is None:
            word_site = "https://www.mit.edu/~ecprice/wordlist.10000"
            response = requests.get(word_site)
            cls.words = response.content
            cls.words = cls.words.decode('utf8').splitlines()
            random.seed()
        return cls.instance

    def get_words(self, no_of_words=10):
        if no_of_words < 0:
            no_of_words = 10
        if no_of_words > len(self.words):
            no_of_words = 10
        try:
            no_of_words = int(no_of_words)
        except Exception as msg:
            no_of_words = 10
        text_words = self.words[random.randrange(len(self.words))]
        for wrd in range(no_of_words - 1):
            text_words += f' {self.words[random.randrange(len(self.words))]}'
        return text_words


if __name__ == '__main__':
    rw = RandWords()
    print(f'{rw.get_words()}')
